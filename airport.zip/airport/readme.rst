#########################
WELCOME TO AIRPORT API
#########################

Author: shahbaz 
shahbazbsit16@gmail.com


*****************************
Methods included in this API
*****************************

1- ADD
TYPE : POST
<http://localhost/airport/add>`.
2- UPDATE
TYPE : POST
<http://localhost/airport/update>`.
3- DELETE
TYPE : POST
<http://localhost/airport/delete>`.
4-GET
TYPE : POST
<http://localhost/airport/all>`.
5-SEARCH
<http://localhost/airport/search>`.
TYPE : GET

*****************************
USERS 
*****************************
Table name = users
1- ADMIN ROLE 
user name = shahbaz.admin
user id   = 1
2- ADMIN USER
user name = shahbaz.user
user id   = 2

3- ADMIN GUEST 
user name = shahbaz.guest
user id   = 3



*******************
Methods Document
*******************
<http://localhost/airport/ddocumentation/API METHODS.>



*******************
Server Requirements
*******************
CODEIGNITOR 3.0 is used here
PHP version 5.4 or newer is recommended.
Preferable XAMPP

It should work on 5.2.4 as well, but we strongly advise you NOT to run
such old versions of PHP, because of potential security and performance
issues, as well as missing features.

************
Installation
************

Please copy the airport section into your htdocs forlder
and create database with name "airport"
and import the file 
<http://localhost/airport/database/airport.sql>

*******
License 
*******
This API is Created for CUREAXIOM
SO LICENSE GOES TO THIS COMPANY
*********
Resources
*********

-  `User Guide <https://codeigniter.com/docs>`_

***************
Acknowledgement
***************

I would like to thank EllisLab, all the
contributors to the CodeIgniter project and you, the CodeIgniter user.